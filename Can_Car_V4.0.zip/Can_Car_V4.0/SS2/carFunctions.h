/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_CARFUNCTIONS_H
#define	XC_CARFUNCTIONS_H

typedef enum 
{
    E_NULL=0,
    E_INIT,
    E_CONTACT_OFF,
    E_CONTACT_ON,
    E_TEMPOMAT_ON,
    E_TEMPOMAT_OFF,
    E_HIGH_BRAKE,
    E_BRAKE_RELEASE,
    E_ACCEL_PEDAL, 
    E_IGNITION_DELAY,
    E_GEAR_CHANGE,
    E_VERIFY_GEAR,
    E_SAFETY,
    E_TIMER_50MS,
    E_TIMER_100MS,
    E_TIME
            
}Event_id;


#include <xc.h> // include processor files - each processor file is guarded.  
#include "xf/xf.h"
bool lightControl_Process(struct Event_* ev);
bool brakeControl_Process(struct Event_* ev);
bool motorControl_Process(struct Event_* ev);
bool gearControl_Process(struct Event_* ev);
bool cockpitControl_Process(struct Event_* ev);
bool timeControl_Process(Event* ev);

void updateCarState(void);

void lightControl_FrontLight(uint8_t light);
void lightControl_BackLight(uint8_t light);
void powerControl_Motor(uint8_t power, uint8_t starter);
void powerControl_Gear(uint8_t gear);
void sendTime(void);

#endif

