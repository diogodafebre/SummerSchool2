/*
 * File:   carFunctions.c
 * Author: pascal.sartoret
 *
 * Created on 1. d�cembre 2023, 15:10
 */


#include <xc.h>
#include "mcc_generated_files/mcc.h"

#include <string.h>
#include "can/can.h"
#include "car_msg_id.h"
#include "carFunctions.h"
#include "xf/event.h"
#include <math.h>
#include <stdlib.h>
#include <time.h>

extern CarState carState;

static bool safetyBrake = false;

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))


// Function to simulate and send the current time over CAN every call
void sendTime(void)
{
    // Static variables to keep time and blinking state between calls
    static uint32_t counter = 0;
    static uint8_t blink = 0;
    static uint8_t hour = 13;
    static uint8_t minute = 0;

    // CAN message and data buffer
    CAN_TX_MSGOBJ txMsg;
    uint8_t txData[8];

    counter++; // Increase call counter

    // Update time every 60 calls (simulate one minute)
    if (counter % 60 == 0) {
        if (++minute == 60) {     // Roll over minutes
            minute = 0;
            if (++hour == 24)     // Roll over hours
                hour = 0;
        }
    }

    blink = ~blink; // Toggle blink state (for ":" display)

    // Prepare CAN message
    memset(&txMsg, 0, sizeof(txMsg));
    txMsg.bF.id.ID = ID_TIME;
    txMsg.bF.ctrl.DLC = CAN_DLC_3; // Sending 3 bytes: hour, minute, blink

    // Fill data
    txData[0] = hour;
    txData[1] = minute;
    txData[2] = blink & 0x01; // Keep only the LSB to indicate blinking (0 or 1)

    // Send the CAN message
    CanSend(&txMsg, txData);
}

 
bool timeControl_Process(Event* ev) {
    typedef enum {
        INIT,
        TIME_RUN
    } TimeState;
    static TimeState state = INIT;
    switch (state) {  // Transition machine d'�tat 
        case INIT:
            if (ev->id == E_INIT) {
                state = TIME_RUN;
            }
            break;
        case TIME_RUN:
            if (ev->id == E_TIME) {
                // Ex�cution du code li� au temps 
            }
            break;
        default:
            break;
    }
 
    // Actions � ex�cuter en entrant dans un �tat
    switch (state) {
        case INIT:
             sendTime();
            XF_post(timeControl_Process, E_TIME,1000);
        case TIME_RUN:
            sendTime();
            XF_post(timeControl_Process, E_TIME, 1000);
            break;
        default:
            break;
    }
 
    return 0;
}

// Function to control the front light by sending a CAN message
void lightControl_FrontLight(uint8_t power)
{
    CAN_TX_MSGOBJ txObj;      // CAN message object for transmission
    uint8_t txData[] = {power}; // Data to send, containing the light state

    // Set the message ID to the predefined front light ID
    txObj.bF.id.ID = ID_LIGHT_FRONT;

    // Set message control parameters
    txObj.bF.ctrl.DLC = CAN_DLC_1;  // Data Length Code = 1 byte
    txObj.bF.ctrl.IDE = 0;          // Standard identifier (not extended)
    txObj.bF.ctrl.RTR = 0;          // Data frame (not a remote request)

    // Send the CAN message with the data
    CanSend(&txObj, txData);
}


// Function to control the back light by sending a CAN message
void lightControl_BackLight(uint8_t power)
{
    CAN_TX_MSGOBJ txObj;        // CAN message object for transmission
    uint8_t txData[] = {power}; // Data to send: light state (on/off)

    // Set the CAN message ID for the back light
    txObj.bF.id.ID = ID_LIGHT_BACK;

    // Configure CAN message control fields
    txObj.bF.ctrl.DLC = CAN_DLC_1; // 1 byte of data
    txObj.bF.ctrl.IDE = 0;         // Use standard identifier
    txObj.bF.ctrl.RTR = 0;         // This is a data frame, not a request

    // Send the CAN message
    CanSend(&txObj, txData);
}


// Function to control motor power and starter via CAN message
void powerControl_Motor(uint8_t power, uint8_t starter)
{
    CAN_TX_MSGOBJ txObj;           // CAN message object for transmission
    uint8_t txData[] = {power, starter}; // Data to send: power level and starter state

    // Set the CAN message ID for motor power control
    txObj.bF.id.ID = ID_PWR_MOTOR;

    // Configure CAN message control fields
    txObj.bF.ctrl.DLC = CAN_DLC_2; // 2 bytes of data
    txObj.bF.ctrl.IDE = 0;         // Standard identifier
    txObj.bF.ctrl.RTR = 0;         // Data frame (not a remote request)

    // Send the CAN message
    CanSend(&txObj, txData);
}


// Function to control brake power via CAN message
void powerControl_Brake(uint8_t power)
{
    CAN_TX_MSGOBJ txObj;          // CAN message object for transmission
    uint8_t txData[] = {power};   // Data to send: brake power level

    // Set the CAN message ID for brake control
    txObj.bF.id.ID = ID_PWR_BRAKE;

    // Configure CAN message control fields
    txObj.bF.ctrl.DLC = CAN_DLC_1; // 1 byte of data
    txObj.bF.ctrl.IDE = 0;         // Standard identifier
    txObj.bF.ctrl.RTR = 0;         // Data frame (not a remote request)

    // Send the CAN message
    CanSend(&txObj, txData);
}


// Function to control the gear level via CAN message
void powerControl_Gear(uint8_t gear)
{
    CAN_TX_MSGOBJ txObj;         // CAN message object for transmission
    uint8_t txData[] = {gear};   // Data to send: gear level

    // Set the CAN message ID for gear control
    txObj.bF.id.ID = ID_GEAR_LVL;

    // Configure CAN message control fields
    txObj.bF.ctrl.DLC = CAN_DLC_1; // 1 byte of data
    txObj.bF.ctrl.IDE = 0;         // Standard identifier
    txObj.bF.ctrl.RTR = 0;         // Data frame (not a remote request)

    // Send the CAN message
    CanSend(&txObj, txData);
}


// Function to disable the cruise control (tempomat) via CAN message
void tempomat_Control(void)
{
    CAN_TX_MSGOBJ txObj; // CAN message object for transmission

    // Set the CAN message ID to disable cruise control
    txObj.bF.id.ID = ID_TEMPO_OFF;

    // Configure CAN message control fields
    txObj.bF.ctrl.DLC = CAN_DLC_0; // No data bytes
    txObj.bF.ctrl.IDE = 0;         // Standard identifier
    txObj.bF.ctrl.RTR = 0;         // Data frame (not a remote request)

    // Send the CAN message with no data
    CanSend(&txObj, NULL);
}


// Function to send a kilometer pulse to the cockpit via CAN message
void cockpit_SendKmPulse(void)
{
    CAN_TX_MSGOBJ txObj; // CAN message object for transmission

    // Set the CAN message ID for kilometer pulse
    txObj.bF.id.ID = ID_KM_PULSE;

    // Configure CAN message control fields
    txObj.bF.ctrl.DLC = 0;     // No data bytes
    txObj.bF.ctrl.IDE = 0;     // Standard identifier
    txObj.bF.ctrl.RTR = 0;     // Data frame (not a remote request)

    // Send the CAN message with no data
    CanSend(&txObj, NULL);
}


// Function to process brake-related events
// Takes an event pointer as input and returns a boolean (always false here)
bool brakeControl_Process(Event* ev)
{
    switch (ev->id) {
        case E_HIGH_BRAKE:
            // If safety brake is not active, apply brake power
            if (!safetyBrake)
                powerControl_Brake(carState.brakePedal);

            // Notify the light control module that braking is active
            XF_post(lightControl_Process, E_HIGH_BRAKE, 0);
            break;

        case E_BRAKE_RELEASE:
            // If safety brake is not active, release the brake
            if (!safetyBrake)
                powerControl_Brake(0);

            // Notify the light control module that braking has been released
            XF_post(lightControl_Process, E_BRAKE_RELEASE, 0);
            break;
    }

    // Always return false (no need to keep the event alive)
    return false;
}


// Function to handle cockpit events and manage distance-based pulse generation
bool cockpitControl_Process(Event* ev)
{
    // Internal state of the cockpit system
    typedef enum
    {
        STATE_INIT,
        STATE_OFF,
        STATE_RUN
    } CockpitState;

    // Persistent variables
    static CockpitState currentState = STATE_INIT;
    static CockpitState previousState = STATE_INIT;
    static float traveledDistance = 0.0f;    // Accumulated distance in meters
    static uint32_t pulseCounter = 0;        // Number of pulses sent (each 50m)

    // State machine transitions
    switch (currentState) 
    {
        case STATE_INIT:
            if (ev->id == E_INIT)
                currentState = STATE_OFF;
            break;

        case STATE_OFF:
            if (ev->id == E_CONTACT_ON)
                currentState = STATE_RUN;
            break;

        case STATE_RUN:
            if (ev->id == E_CONTACT_OFF)
                currentState = STATE_OFF;
            break;

        default:
            break;
    }

    // If state hasn't changed, perform actions based on current state
    if (currentState == previousState)
    {
        if (currentState == STATE_RUN && ev->id == E_TIMER_100MS)
        {
            // Calculate speed in m/s from km/h and accumulate distance
            float speed_m_per_s = fabs(carState.speed / 3.6f);
            traveledDistance += speed_m_per_s * 0.1f;  // 0.1s = 100ms

            // Send pulse every 50 meters
            if (traveledDistance >= 50.0f)
            {
                traveledDistance -= 50.0f;
                pulseCounter += 50;
                cockpit_SendKmPulse();
            }

            // Continue the periodic timer
            XF_post(cockpitControl_Process, E_TIMER_100MS, 100);
        }
    }
    else
    {
        // On entering a new state
        if (currentState == STATE_RUN)
        {
            // Start the timer loop when entering RUN state
            XF_post(cockpitControl_Process, E_TIMER_100MS, 100);
        }
    }

    // Update previous state for next loop
    previousState = currentState;

    return false;
}



// Function to process motor-related events and manage engine behavior
bool motorControl_Process(Event* ev)
{
    // States of the motor control state machine
    typedef enum
    {
        STATE_INIT,
        STATE_OFF,
        STATE_IGNITION,
        STATE_RUN,
        STATE_CRUISE
    } MotorState;

    // Persistent variables
    static MotorState currentState = STATE_INIT;
    static MotorState previousState = STATE_INIT;
    static uint8_t minAccel = 0;  // Minimum allowed acceleration

    // === State transitions ===
    switch (currentState)
    {
        case STATE_INIT:
            if (ev->id == E_INIT)
                currentState = STATE_OFF;
            break;

        case STATE_OFF:
            if (ev->id == E_CONTACT_ON)
                currentState = STATE_IGNITION;
            break;

        case STATE_IGNITION:
            if (ev->id == E_IGNITION_DELAY)
                currentState = STATE_RUN;
            break;

        case STATE_RUN:
            if (ev->id == E_CONTACT_OFF)
                currentState = STATE_OFF;
            else if (ev->id == E_TEMPOMAT_ON)
                currentState = STATE_CRUISE;
            break;

        case STATE_CRUISE:
            if (ev->id == E_HIGH_BRAKE || ev->id == E_TEMPOMAT_OFF)
            {
                tempomat_Control(); // Disable cruise control
                currentState = STATE_RUN;
            }
            else if (ev->id == E_CONTACT_OFF)
                currentState = STATE_OFF;
            break;

        default:
            break;
    }

    // === State behavior (when not changing state) ===
    if (currentState == previousState)
    {
        switch (currentState)
        {
            case STATE_RUN:
                if (ev->id == E_TIMER_50MS || ev->id == E_ACCEL_PEDAL)
                {
                    // Determine if the starter should be activated
                    uint8_t starter = (carState.rpm == 0) ? 1 : 0;

                    // Gradually increase minimum acceleration when RPM is low
                    if (carState.rpm < 800)
                        minAccel = MIN(minAccel + 1, 10);
                    else
                        minAccel = 8;

                    // Safety: limit power at high RPM
                    if ((carState.rpm > 7900 && carState.gearLevel == 5) ||
                        (carState.rpm > 7900 && carState.gearSel == 'R'))
                    {
                        powerControl_Motor(50, 0);
                    }
                    else
                    {
                        uint8_t accelValue = MAX(minAccel, carState.accelPedal - 10);
                        powerControl_Motor(accelValue, starter);
                    }

                    // Restart timer for periodic update
                    if (ev->id == E_TIMER_50MS)
                        XF_post(motorControl_Process, E_TIMER_50MS, 50);
                }
                break;

            case STATE_CRUISE:
                if (ev->id == E_TIMER_50MS)
                {
                    // Cruise control regulation logic
                    if (carState.speed < carState.tempoSpeed)
                        carState.RegulationAccel++;
                    else if (carState.speed > carState.tempoSpeed)
                        carState.RegulationAccel--;

                    powerControl_Motor(carState.RegulationAccel, 0);

                    // Continue periodic regulation
                    XF_post(motorControl_Process, E_TIMER_50MS, 50);
                }
                break;

            default:
                break;
        }
    }

    // === On state change ===
    else
    {
        switch (currentState)
        {
            case STATE_OFF:
                powerControl_Gear(0);               // Reset gear
                powerControl_Motor(0, 0);           // Turn off engine
                break;

            case STATE_IGNITION:
                XF_post(motorControl_Process, E_IGNITION_DELAY, 200); // Simulate ignition delay
                break;

            case STATE_RUN:
                if (carState.rpm == 0)
                    powerControl_Motor(6, 1);       // Start engine with starter
                else
                    powerControl_Motor(6, 0);       // Idle mode

                XF_post(motorControl_Process, E_TIMER_50MS, 100);
                break;

            case STATE_CRUISE:
                powerControl_Motor(carState.RegulationAccel, 0);
                XF_post(motorControl_Process, E_TIMER_50MS, 50);
                break;

            default:
                break;
        }
    }

    // Update previous state
    previousState = currentState;

    return false;
}



// Function to handle gear control and safety brake logic
bool gearControl_Process(Event* ev)
{
    static uint8_t oldGearLevel = 0; // Keeps track of the previously applied gear level

    switch(ev->id)
    {
        // === Manual gear selector change ===
        case E_GEAR_CHANGE:
            carState.gearLevel = 0;                       // Reset to neutral
            powerControl_Gear(carState.gearLevel);        // Send neutral over CAN
            safetyBrake = false;                          // Release safety brake
            oldGearLevel = 0;

            if (carState.gearSel == 'N')                  // If selector is on Neutral
                XF_post(brakeControl_Process, E_BRAKE_RELEASE, 0); // Release brake
            break;

        // === Periodic check to adjust gear based on RPM and selector ===
        case E_VERIFY_GEAR:
            if (carState.gearSel == 'P' || carState.gearSel == 'N')
                safetyBrake = false; // No gear logic in Park or Neutral

            // Reverse gear logic
            else if (carState.gearSel == 'R')
            {
                XF_post(gearControl_Process, E_SAFETY, 0); // Always check safety

                if (carState.rpm > 1100 && carState.gearLevel != 1)
                {
                    carState.gearLevel = 1;               // Engage reverse gear
                    powerControl_Gear(carState.gearLevel);
                }
            }

            // Drive mode (automatic shifting)
            else if (carState.gearSel == 'D')
            {
                XF_post(gearControl_Process, E_SAFETY, 0); // Safety check

                // === Upshift logic ===
                if (carState.rpm >= 6000 && oldGearLevel == 4)
                    carState.gearLevel = 5;
                else if (carState.rpm >= 5000 && oldGearLevel == 3)
                    carState.gearLevel = 4;
                else if (carState.rpm >= 4500 && oldGearLevel == 2)
                    carState.gearLevel = 3;
                else if (carState.rpm >= 4000 && oldGearLevel == 1)
                    carState.gearLevel = 2;
                else if (carState.rpm >= 1100 && oldGearLevel == 0)
                    carState.gearLevel = 1;

                // === Downshift logic ===
                if (carState.rpm <= 4000 && oldGearLevel == 5)
                    carState.gearLevel = 4;
                else if (carState.rpm <= 3500 && oldGearLevel == 4)
                    carState.gearLevel = 3;
                else if (carState.rpm <= 3000 && oldGearLevel == 3)
                    carState.gearLevel = 2;
                else if (carState.rpm <= 2000 && oldGearLevel == 2)
                    carState.gearLevel = 1;
                else if (carState.rpm <= 1100 && oldGearLevel == 1)
                    carState.gearLevel = 0;
            }

            // Limit to one gear change per cycle
            if (abs(carState.gearLevel - oldGearLevel) > 1)
            {
                if (carState.gearLevel > oldGearLevel)
                    carState.gearLevel = oldGearLevel + 1;
                else
                    carState.gearLevel = oldGearLevel - 1;
            }

            // Apply gear change if needed
            if (carState.gearLevel != oldGearLevel)
            {
                powerControl_Gear(carState.gearLevel);
                oldGearLevel = carState.gearLevel;
            }
            break;

        // === Safety logic: force braking and neutral if unsafe ===
        case E_SAFETY:
            if (carState.rpm < 1100)
            {
                // If speed is very low and brake not yet applied, apply it
                if (!safetyBrake && carState.speed < 1)
                {
                    powerControl_Brake(100); // Apply brake
                    safetyBrake = true;
                }

                // If not already in neutral, force it
                if (carState.gearLevel != 0)
                {
                    carState.gearLevel = 0;
                    powerControl_Gear(carState.gearLevel);
                }
            }
            else
            {
                // If RPM is sufficient, release the safety brake
                if (safetyBrake)
                {
                    powerControl_Brake(0);
                    safetyBrake = false;
                }
            }
            break;

        // === Default: release safety brake if it was still active ===
        default:
            if (safetyBrake)
            {
                powerControl_Brake(0); // Release brake
                safetyBrake = false;
            }
            break;
    }

    return false;
}



// Function to manage the light control state machine based on vehicle events
bool lightControl_Process(Event* ev)
{
    // Define the states of the light system
    typedef enum {
        STATE_INIT,
        STATE_OFF,
        STATE_CRUISE,
        STATE_BRAKE
    } LightState;

    // Persistent variables to track current and previous state
    static LightState currentState = STATE_INIT;
    static LightState previousState = STATE_INIT;

    // === State Transition Logic ===
    switch (currentState)
    {
        case STATE_INIT:
            if (ev->id == E_INIT)
                currentState = STATE_OFF;
            break;

        case STATE_OFF:
            if (ev->id == E_CONTACT_ON)
                currentState = STATE_CRUISE;
            break;

        case STATE_CRUISE:
            if (ev->id == E_HIGH_BRAKE)
                currentState = STATE_BRAKE;
            else if (ev->id == E_CONTACT_OFF)
                currentState = STATE_OFF;
            break;

        case STATE_BRAKE:
            if (ev->id == E_BRAKE_RELEASE)
                currentState = STATE_CRUISE;
            else if (ev->id == E_CONTACT_OFF)
                currentState = STATE_OFF;
            break;

        default:
            break;
    }

    // === If no state change, no further action is required ===
    if (currentState == previousState)
        return false;

    // Update the last known state
    previousState = currentState;

    // === Entry actions for each state ===
    switch (currentState)
    {
        case STATE_OFF:
            lightControl_FrontLight(0);    // Turn off all lights
            lightControl_BackLight(0);
            break;

        case STATE_CRUISE:
            lightControl_FrontLight(50);   // Dimmed lights for driving
            lightControl_BackLight(50);
            break;

        case STATE_BRAKE:
            lightControl_BackLight(100);   // Full brightness for braking
            break;

        default:
            break;
    }

    return false;
}


// Function to update the car state based on received CAN messages
void updateCarState(void) 
{
    CAN_RX_MSGOBJ rxObj;      // CAN message object for reception
    uint8_t rxData[8];        // Buffer to hold received data

    // Check if a CAN message has been received
    if (CanReceive(&rxObj, rxData) == 0) 
    {
        // Use masked ID to identify message type
        switch (rxObj.bF.id.ID & 0x7F0)
        {
            // === Contact key ON/OFF ===
            case ID_CONTACT_KEY:
                carState.contactKey = rxData[0];

                if (rxData[0] == 0)  // Contact OFF
                {
                    carState.rpm = 0;
                    carState.gearSel = 'P';
                    carState.gearLevel = 0;

                    XF_post(lightControl_Process, E_CONTACT_OFF, 0);
                    XF_post(motorControl_Process, E_CONTACT_OFF, 0);
                }
                else  // Contact ON
                {
                    XF_post(lightControl_Process, E_CONTACT_ON, 0);
                    XF_post(motorControl_Process, E_CONTACT_ON, 0);
                    XF_post(cockpitControl_Process, E_CONTACT_ON, 0);
                }
                break;

            // === Brake pedal position ===
            case ID_BRAKE_PEDAL:
                carState.brakePedal = rxData[0];

                if (carState.brakePedal > 0x08)  // Brake threshold
                {
                    XF_post(brakeControl_Process, E_HIGH_BRAKE, 0);
                    XF_post(motorControl_Process, E_HIGH_BRAKE, 0);
                }
                else
                {
                    XF_post(brakeControl_Process, E_BRAKE_RELEASE, 0);
                }
                break;

            // === Accelerator pedal position ===
            case ID_ACCEL_PEDAL:
                carState.accelPedal = rxData[0];

                XF_post(motorControl_Process, E_ACCEL_PEDAL, 0);
                XF_post(gearControl_Process, E_VERIFY_GEAR, 0);
                break;

            // === Gear selector (P, N, R, D) ===
            case ID_GEAR_SEL:
                if (carState.gearSel != rxData[0])
                {
                    carState.gearSel = rxData[0];
                    XF_post(gearControl_Process, E_GEAR_CHANGE, 0);
                }
                break;

            // === Motor status: RPM and speed ===
            case ID_MOTOR_STATUS:
                // Decode RPM (16-bit: MSB + LSB)
                carState.rpm = (uint16_t)((rxData[0] << 8) | rxData[1]);

                // Decode speed (signed 16-bit)
                carState.speed = (uint16_t)((rxData[2] << 8) | rxData[3]);

                XF_post(gearControl_Process, E_VERIFY_GEAR, 0);
                break;

            // === Tempomat (Cruise Control) ===
            case ID_TEMPOMAT:
                if (rxData[0] == 0)
                {
                    XF_post(motorControl_Process, E_TEMPOMAT_OFF, 0);
                }
                else if (rxData[0] == 1)
                {
                    // Save the current acceleration and target speed
                    carState.RegulationAccel = carState.accelPedal;
                    carState.tempoSpeed = rxData[1];

                    XF_post(motorControl_Process, E_TEMPOMAT_ON, 0);
                }
                break;

            default:
                // Unknown message ID ? ignore
                break;
        }
    }
}



